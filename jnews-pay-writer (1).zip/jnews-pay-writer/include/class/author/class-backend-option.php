<?php

namespace JNews\PAY_WRITER\Author;

/**
 * Backend Option
 *
 * @author Jegtheme
 * @since 10.0.0
 * @package JNews\PAY_WRITER\Author
 */

use JNews\Archive\Builder\OptionAbstract;
use JNews\PAY_WRITER\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Backend_Option
 */
class Backend_Option extends OptionAbstract {

	/**
	 * Backend_Option constructor.
	 * Calls setup_hook.
	 */
	public function __construct() {
		$this->setup_hook();
	}

	/**
	 * Setup Hook
	 */
	protected function setup_hook() {
		// Hooks for backend user profile page
		add_action( 'show_user_profile', array( $this, 'render_options' ) );
		add_action( 'edit_user_profile', array( $this, 'render_options' ) );

		add_action( 'edit_user_profile_update', array( $this, 'save_user' ) );
		add_action( 'personal_options_update', array( $this, 'save_user' ) );

		add_action( 'wpmu_delete_user', array( $this, 'remove_user_data' ) );
		add_action( 'delete_user', array( $this, 'remove_user_data' ) );
		add_action( 'make_spam_user', array( $this, 'remove_user_data' ) );

		// Hook for enqueuing admin scripts (including media uploader for backend profile)
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

		// Hooks for frontend WooCommerce My Account page
		add_action( 'woocommerce_edit_account_form_end', array( $this, 'render_frontend_options' ) );
		add_action( 'woocommerce_save_account_details', array( $this, 'save_frontend_user_data' ), 10, 1 );

		// Hook for enqueuing frontend scripts (including media uploader for frontend profile)
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_scripts' ) );
	}

	/**
	 * Enqueue admin scripts for the user profile page.
	 */
	public function enqueue_admin_scripts() {
		$screen = get_current_screen();
		if ( $screen && ( 'profile' === $screen->id || 'user-edit' === $screen->id ) ) {
			wp_enqueue_media();
			wp_add_inline_script( 'jquery', '
				jQuery(document).ready(function($) {
					$(document).on("click", ".jpwt-upload-button", function(e) {
						e.preventDefault();
						var button = $(this);
						var fieldId = button.data("field-id");
						var library = button.data("library"); // e.g., "image,application/pdf"

						var custom_uploader = wp.media({
							title: "Pilih File",
							library: { type: library },
							button: { text: "Pilih" },
							multiple: false
						}).on("select", function() {
							var attachment = custom_uploader.state().get("selection").first().toJSON();
							$("#" + fieldId).val(attachment.id);
							var fileHtml = "";
							if (attachment.type === "image") {
								fileHtml = \'<img src="\' + attachment.url + \'" style="max-width: 200px; height: auto; display: block; margin-bottom: 10px;" />\';
							} else {
								fileHtml = \'<p><a href="\' + attachment.url + \'" target="_blank">\' + attachment.filename + \'</a></p>\';
							}
							button.parent().find(".jpwt-current-file").remove();
							button.before(\'<div class="jpwt-current-file">\' + fileHtml + \'<label for="\' + fieldId + \'_delete"><input type="checkbox" name="\' + fieldId + \'_delete" id="\' + fieldId + \'_delete" value="1" /> \' + ' . wp_json_encode( esc_html__( 'Hapus File', 'jnews-pay-writer' ) ) . ' + \'</label></div>\');
						}).open();
					});

					$(document).on("change", "input[type=checkbox][name$=\'_delete\']", function() {
						var checkbox = $(this);
						var fieldId = checkbox.attr("id").replace("_delete", "");
						if (checkbox.is(":checked")) {
							$("#" + fieldId).val("");
							checkbox.closest(".jpwt-current-file").hide();
						} else {
							var currentFileId = $("#" + fieldId).val();
							if (currentFileId) {
								checkbox.closest(".jpwt-current-file").show();
							}
						}
					});
				});
			' );
		}
	}

	/**
	 * Enqueue frontend scripts for WooCommerce My Account edit page.
	 */
	public function enqueue_frontend_scripts() {
		if ( function_exists( 'is_account_page' ) && is_account_page() && ! is_admin() ) {
			global $wp;
			if ( isset( $wp->query_vars['edit-account'] ) ) {
				if ( current_user_can( 'edit_user', get_current_user_id() ) ) {
					wp_enqueue_media();
					wp_add_inline_script( 'jquery', '
						jQuery(document).ready(function($) {
							$(document).on("click", ".jpwt-upload-button", function(e) {
								e.preventDefault();
								var button = $(this);
								var fieldId = button.data("field-id");
								var library = button.data("library");

								var custom_uploader = wp.media({
									title: "Pilih File",
									library: { type: library },
									button: { text: "Pilih" },
									multiple: false
								}).on("select", function() {
									var attachment = custom_uploader.state().get("selection").first().toJSON();
									$("#" + fieldId).val(attachment.id);
									var fileHtml = "";
									if (attachment.type === "image") {
										fileHtml = \'<img src="\' + attachment.url + \'" style="max-width: 200px; height: auto; display: block; margin-bottom: 10px;" />\';
									} else {
										fileHtml = \'<p><a href="\' + attachment.url + \'" target="_blank">\' + attachment.filename + \'</a></p>\';
									}
									button.parent().find(".jpwt-current-file").remove();
									button.before(\'<div class="jpwt-current-file">\' + fileHtml + \'<label for="\' + fieldId + \'_delete"><input type="checkbox" name="\' + fieldId + \'_delete" id="\' + fieldId + \'_delete" value="1" /> \' + ' . wp_json_encode( esc_html__( 'Hapus File', 'jnews-pay-writer' ) ) . ' + \'</label></div>\');
								}).open();
							});

							$(document).on("change", "input[type=checkbox][name$=\'_delete\']", function() {
								var checkbox = $(this);
								var fieldId = checkbox.attr("id").replace("_delete", "");
								if (checkbox.is(":checked")) {
									$("#" + fieldId).val("");
									checkbox.closest(".jpwt-current-file").hide();
								} else {
									var currentFileId = $("#" + fieldId).val();
									if (currentFileId) {
										checkbox.closest(".jpwt-current-file").show();
									}
								}
							});
						});
					' );
				}
			}
		}
	}

	/**
	 * Removes pay writer data for all users from a user who is deleted or spammed
	 *
	 * @param int $user_id User ID.
	 */
	public function remove_user_data( $user_id ) {
		do_action( 'jpwt_before_remove_user_data', $user_id );

		$options = $this->get_options();
		$this->do_delete( $options, $user_id );

		do_action( 'jpwt_remove_user_data', $user_id );
	}

	/**
	 * Save pay writer data for all users from a user who is save user data
	 * (Used for backend profile page)
	 *
	 * @param int $user_id User ID.
	 */
	public function save_user( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}

		$fields_to_save = array(
			'jpwt_id_card_number',
			'jpwt_whatsapp_number',
			'jpwt_full_address',
			'jpwt_bank_name',
			'jpwt_bank_account_holder_name',
			'jpwt_bank_account_number',
		);

		foreach ( $fields_to_save as $field_key ) {
			if ( isset( $_POST[ $field_key ] ) ) {
				update_user_meta( $user_id, $field_key, sanitize_text_field( wp_unslash( $_POST[ $field_key ] ) ) );
			} else {
				delete_user_meta( $user_id, $field_key );
			}
		}

		$file_fields = array(
			'jpwt_id_card_file',
			'jpwt_bank_book_file',
		);

		foreach ( $file_fields as $file_field_key ) {
			if ( ! empty( $_FILES[ $file_field_key ]['name'] ) ) {
				$upload_dir = wp_upload_dir();
				if ( ! empty( $upload_dir['error'] ) ) {
					error_log( 'JPW_Backend_Option: Error getting upload directory: ' . $upload_dir['error'] );
					continue;
				}

				$this->require_once_if_not_already_included( ABSPATH . 'wp-admin/includes/image.php' );
				$this->require_once_if_not_already_included( ABSPATH . 'wp-admin/includes/file.php' );
				$this->require_once_if_not_already_included( ABSPATH . 'wp-admin/includes/media.php' );

				$attachment_id = media_handle_upload( $file_field_key, 0 );
				if ( is_wp_error( $attachment_id ) ) {
					error_log( 'JPW_Backend_Option: Error uploading file ' . $file_field_key . ': ' . $attachment_id->get_error_message() );
				} else {
					update_user_meta( $user_id, $file_field_key, $attachment_id );
				}
			} elseif ( isset( $_POST[ $file_field_key . '_delete' ] ) && $_POST[ $file_field_key . '_delete' ] === '1' ) {
				$existing_attachment_id = get_user_meta( $user_id, $file_field_key, true );
				if ( $existing_attachment_id ) {
					wp_delete_attachment( $existing_attachment_id, true );
					delete_user_meta( $user_id, $file_field_key );
				}
			}
		}

		parent::do_save( $this->get_options(), $user_id );
	}

	/**
	 * Save frontend user data from WooCommerce My Account page.
	 *
	 * @param int $user_id User ID.
	 */
	public function save_frontend_user_data( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}

		$fields_to_save = array(
			'jpwt_id_card_number',
			'jpwt_whatsapp_number',
			'jpwt_full_address',
			'jpwt_bank_name',
			'jpwt_bank_account_holder_name',
			'jpwt_bank_account_number',
		);

		foreach ( $fields_to_save as $field_key ) {
			if ( isset( $_POST[ $field_key ] ) ) {
				update_user_meta( $user_id, $field_key, sanitize_text_field( wp_unslash( $_POST[ $field_key ] ) ) );
			} else {
				delete_user_meta( $user_id, $field_key );
			}
		}

		$file_fields = array(
			'jpwt_id_card_file',
			'jpwt_bank_book_file',
		);

		foreach ( $file_fields as $file_field_key ) {
			if ( ! empty( $_FILES[ $file_field_key ]['name'] ) ) {
				$this->require_once_if_not_already_included( ABSPATH . 'wp-admin/includes/image.php' );
				$this->require_once_if_not_already_included( ABSPATH . 'wp-admin/includes/file.php' );
				$this->require_once_if_not_already_included( ABSPATH . 'wp-admin/includes/media.php' );

				$attachment_id = media_handle_upload( $file_field_key, 0 );
				if ( is_wp_error( $attachment_id ) ) {
					error_log( 'JPW_Backend_Option (Frontend Save): Error uploading file ' . $file_field_key . ': ' . $attachment_id->get_error_message() );
					wc_add_notice( esc_html__( 'Gagal mengunggah file. ' . $attachment_id->get_error_message(), 'jnews-pay-writer' ), 'error' );
				} else {
					$old_attachment_id = get_user_meta( $user_id, $file_field_key, true );
					if ( $old_attachment_id ) {
						wp_delete_attachment( $old_attachment_id, true );
					}
					update_user_meta( $user_id, $file_field_key, $attachment_id );
				}
			} elseif ( isset( $_POST[ $file_field_key . '_delete' ] ) && $_POST[ $file_field_key . '_delete' ] === '1' ) {
				$existing_attachment_id = get_user_meta( $user_id, $file_field_key, true );
				if ( $existing_attachment_id ) {
					wp_delete_attachment( $existing_attachment_id, true );
					delete_user_meta( $user_id, $file_field_key );
				}
			}
		}
	}

	/**
	 * Helper function to require_once a file only if not already included.
	 *
	 * @param string $file_path The path to the file to include.
	 */
	private function require_once_if_not_already_included( $file_path ) {
		if ( ! in_array( $file_path, get_included_files() ) ) {
			require_once $file_path;
		}
	}

	/**
	 * @param \WP_User $user
	 *
	 * @return int|null
	 */
	protected function get_id( $user ) {
		if ( ! isset( $user->ID ) || empty( $user->ID ) ) {
			return null;
		} else {
			return $user->ID;
		}
	}

	/**
	 * @param string $key Field key.
	 * @param int    $user_id User ID.
	 * @param mixed  $default Default value.
	 *
	 * @return mixed
	 */
	public function get_value( $key, $user_id, $default ) {
		$value = get_user_meta( $user_id, $key, true );

		if ( '' !== $value && null !== $value ) {
			return $value;
		} else {
			$user_option_value = get_user_option( $key, $user_id );
			if ( $user_option_value ) {
				return $user_option_value;
			}
			return $default;
		}
	}

	/**
	 * Overriding parent's do_save to handle new fields as user_meta
	 *
	 * @param array $options Options array.
	 * @param int   $user_id User ID.
	 */
	protected function do_save( $options, $user_id ) {
		if ( isset( $_POST['paypal_account'] ) ) {
			update_user_option( $user_id, 'paypal_account', sanitize_email( wp_unslash( $_POST['paypal_account'] ) ) );
		}
	}

	/**
	 * Overriding parent's do_delete to handle new fields from user_meta
	 *
	 * @param array $options Options array.
	 * @param int   $user_id User ID.
	 */
	protected function do_delete( $options, $user_id ) {
		$fields_to_delete = array(
			'jpwt_id_card_number',
			'jpwt_id_card_file',
			'jpwt_bank_book_file',
			'jpwt_whatsapp_number',
			'jpwt_full_address',
			'jpwt_bank_name',
			'jpwt_bank_account_holder_name',
			'jpwt_bank_account_number',
		);

		foreach ( $fields_to_delete as $field_key ) {
			if ( in_array( $field_key, array( 'jpwt_id_card_file', 'jpwt_bank_book_file' ) ) ) {
				$existing_attachment_id = get_user_meta( $user_id, $field_key, true );
				if ( $existing_attachment_id ) {
					wp_delete_attachment( $existing_attachment_id, true );
				}
			}
			delete_user_meta( $user_id, $field_key );
		}

		parent::do_delete( $options, $user_id );
	}

	/**
	 * Render options field based on type.
	 * (Used for backend profile page)
	 *
	 * @param string $key Field key.
	 * @param array  $field Field definition.
	 * @param mixed  $value Current field value.
	 * @param int    $user_id User ID.
	 */
	protected function render_field( $key, $field, $value, $user_id ) {
		if ( 'upload' === $field['type'] ) {
			$current_file_id  = get_user_meta( $user_id, $key, true );
			$current_file_url = '';
			$is_image         = false;

			if ( $current_file_id ) {
				$current_file_url = wp_get_attachment_url( $current_file_id );
				$file_type        = wp_check_filetype( $current_file_url );
				if ( strpos( $file_type['type'], 'image' ) !== false ) {
					$is_image = true;
				}
			}
			?>
			<tr id="<?php echo esc_attr( $key ); ?>-row">
				<th><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['title'] ); ?></label></th>
				<td>
					<div class="jpwt-file-upload-wrapper">
						<input type="hidden" name="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $current_file_id ); ?>" class="jpwt-upload-field" />
						<?php if ( $current_file_url ) : ?>
							<div class="jpwt-current-file">
								<?php if ( $is_image ) : ?>
									<img src="<?php echo esc_url( $current_file_url ); ?>" style="max-width: 200px; height: auto; display: block; margin-bottom: 10px;" />
								<?php else : ?>
									<p><a href="<?php echo esc_url( $current_file_url ); ?>" target="_blank"><?php echo esc_html( basename( $current_file_url ) ); ?></a></p>
								<?php endif; ?>
								<label for="<?php echo esc_attr( $key ); ?>_delete">
									<input type="checkbox" name="<?php echo esc_attr( $key ); ?>_delete" id="<?php echo esc_attr( $key ); ?>_delete" value="1" />
									<?php esc_html_e( 'Hapus File', 'jnews-pay-writer' ); ?>
								</label>
							</div>
						<?php endif; ?>
						<button type="button" class="button jpwt-upload-button" data-field-id="<?php echo esc_attr( $key ); ?>" data-library="<?php echo esc_attr( $field['options']['library'] ); ?>">
							<?php echo esc_html( $field['options']['button_text'] ); ?>
						</button>
						<p class="description"><?php echo esc_html( $field['desc'] ); ?></p>
					</div>
				</td>
			</tr>
			<?php
		} else {
			parent::render_field( $key, $field, $value, $user_id );
		}
	}

	/**
	 * Render frontend options for WooCommerce My Account edit page.
	 *
	 * @param int $user_id User ID.
	 */
	public function render_frontend_options( $user_id ) {
		$options = $this->get_options();

		echo '<h2 class="woocommerce-column__title">' . esc_html__( 'Data Pribadi Penulis', 'jnews-pay-writer' ) . '</h2>';
		echo '<div class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">';

		$this->render_frontend_fields_by_segment( $user_id, $options, 'jpwt-personal-data' );

		echo '</div>';

		echo '<h2 class="woocommerce-column__title">' . esc_html__( 'Detail Rekening Bank', 'jnews-pay-writer' ) . '</h2>';
		echo '<div class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">';

		$this->render_frontend_fields_by_segment( $user_id, $options, 'jpwt-bank-details' );

		echo '</div>';
	}

	/**
	 * Helper to render fields for a specific segment on the frontend.
	 *
	 * @param int    $user_id User ID.
	 * @param array  $options All defined options.
	 * @param string $segment_id The segment ID to render.
	 */
	private function render_frontend_fields_by_segment( $user_id, $options, $segment_id ) {
		foreach ( $options as $key => $field ) {
			if ( isset( $field['segment'] ) && $field['segment'] === $segment_id ) {
				$value            = $this->get_value( $key, $user_id, $field['default'] );
				$current_file_id  = ( 'upload' === $field['type'] ) ? get_user_meta( $user_id, $key, true ) : '';
				$current_file_url = '';
				$is_image         = false;

				if ( $current_file_id ) {
					$current_file_url = wp_get_attachment_url( $current_file_id );
					$file_type        = wp_check_filetype( $current_file_url );
					if ( strpos( $file_type['type'], 'image' ) !== false ) {
						$is_image = true;
					}
				}

				switch ( $field['type'] ) {
					case 'text':
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['title'] ); ?></label>
							<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>" />
							<?php if ( isset( $field['desc'] ) ) : ?>
								<span class="description"><?php echo esc_html( $field['desc'] ); ?></span>
							<?php endif; ?>
						</p>
						<?php
						break;
					case 'textarea':
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['title'] ); ?></label>
							<textarea class="woocommerce-Input woocommerce-Input--textarea input-text" name="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $key ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
							<?php if ( isset( $field['desc'] ) ) : ?>
								<span class="description"><?php echo esc_html( $field['desc'] ); ?></span>
							<?php endif; ?>
						</p>
						<?php
						break;
					case 'upload':
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['title'] ); ?></label>
							<div class="jpwt-file-upload-wrapper">
								<input type="hidden" name="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $current_file_id ); ?>" class="jpwt-upload-field" />
								<?php if ( $current_file_url ) : ?>
									<div class="jpwt-current-file">
										<?php if ( $is_image ) : ?>
											<img src="<?php echo esc_url( $current_file_url ); ?>" style="max-width: 200px; height: auto; display: block; margin-bottom: 10px;" />
										<?php else : ?>
											<p><a href="<?php echo esc_url( $current_file_url ); ?>" target="_blank"><?php echo esc_html( basename( $current_file_url ) ); ?></a></p>
										<?php endif; ?>
										<label for="<?php echo esc_attr( $key ); ?>_delete">
											<input type="checkbox" name="<?php echo esc_attr( $key ); ?>_delete" id="<?php echo esc_attr( $key ); ?>_delete" value="1" />
											<?php esc_html_e( 'Hapus File', 'jnews-pay-writer' ); ?>
										</label>
									</div>
								<?php endif; ?>
								<button type="button" class="button jpwt-upload-button" data-field-id="<?php echo esc_attr( $key ); ?>" data-library="<?php echo esc_attr( $field['options']['library'] ); ?>">
									<?php echo esc_html( $field['options']['button_text'] ); ?>
								</button>
								<?php if ( isset( $field['desc'] ) ) : ?>
									<span class="description"><?php echo esc_html( $field['desc'] ); ?></span>
								<?php endif; ?>
							</div>
						</p>
						<?php
						break;
				}
			}
		}
	}

	/**
	 * @return array
	 */
	public function prepare_segments() {
		$segments = array();

		$segments[] = array(
			'id'   => 'jpwt-personal-data',
			'name' => esc_html__( 'Data Pribadi Penulis', 'jnews-pay-writer' ),
		);

		$segments[] = array(
			'id'   => 'jpwt-bank-details',
			'name' => esc_html__( 'Detail Rekening Bank', 'jnews-pay-writer' ),
		);

		$segments[] = array(
			'id'   => 'jnews-paypal-credential',
			'name' => esc_html__( 'Kredensial Paypal JNews', 'jnews-pay-writer' ),
		);

		return $segments;
	}

	/**
	 * @return array
	 */
	protected function get_options() {
		$options = array();

		$options['jpwt_id_card_number'] = array(
			'segment' => 'jpwt-personal-data',
			'title'   => esc_html__( 'Nomor KTP', 'jnews-pay-writer' ),
			'desc'    => esc_html__( 'Masukkan Nomor Induk Kependudukan (NIK) penulis.', 'jnews-pay-writer' ),
			'type'    => 'text',
			'default' => '',
		);

		$options['jpwt_id_card_file'] = array(
			'segment' => 'jpwt-personal-data',
			'title'   => esc_html__( 'File KTP', 'jnews-pay-writer' ),
			'desc'    => esc_html__( 'Unggah file KTP penulis (JPG, PNG, PDF).', 'jnews-pay-writer' ),
			'type'    => 'upload',
			'default' => '',
			'options' => array(
				'button_text' => esc_html__( 'Unggah KTP', 'jnews-pay-writer' ),
				'library'     => 'image,application/pdf',
			),
		);

		$options['jpwt_whatsapp_number'] = array(
			'segment' => 'jpwt-personal-data',
			'title'   => esc_html__( 'Nomor WhatsApp', 'jnews-pay-writer' ),
			'desc'    => esc_html__( 'Masukkan nomor WhatsApp penulis (dengan kode negara, contoh: +62812xxxx).', 'jnews-pay-writer' ),
			'type'    => 'text',
			'default' => '',
			'sanitize_callback' => 'sanitize_text_field',
		);

		$options['jpwt_full_address'] = array(
			'segment' => 'jpwt-personal-data',
			'title'   => esc_html__( 'Alamat Lengkap', 'jnews-pay-writer' ),
			'desc'    => esc_html__( 'Masukkan alamat lengkap penulis.', 'jnews-pay-writer' ),
			'type'    => 'textarea',
			'default' => '',
		);

		$options['jpwt_bank_name'] = array(
			'segment' => 'jpwt-bank-details',
			'title'   => esc_html__( 'Nama Bank', 'jnews-pay-writer' ),
			'desc'    => esc_html__( 'Contoh: BCA, Mandiri, BRI.', 'jnews-pay-writer' ),
			'type'    => 'text',
			'default' => '',
		);

		$options['jpwt_bank_account_holder_name'] = array(
			'segment' => 'jpwt-bank-details',
			'title'   => esc_html__( 'Nama Pemilik Rekening', 'jnews-pay-writer' ),
			'desc'    => esc_html__( 'Nama lengkap pemilik rekening bank.', 'jnews-pay-writer' ),
			'type'    => 'text',
			'default' => '',
		);

		$options['jpwt_bank_account_number'] = array(
			'segment' => 'jpwt-bank-details',
			'title'   => esc_html__( 'Nomor Rekening Bank', 'jnews-pay-writer' ),
			'desc'    => esc_html__( 'Masukkan nomor rekening bank penulis.', 'jnews-pay-writer' ),
			'type'    => 'text',
			'default' => '',
		);

		$options['jpwt_bank_book_file'] = array(
			'segment' => 'jpwt-bank-details',
			'title'   => esc_html__( 'File Buku Rekening', 'jnews-pay-writer' ),
			'desc'    => esc_html__( 'Unggah salinan buku rekening penulis (JPG, PNG, PDF).', 'jnews-pay-writer' ),
			'type'    => 'upload',
			'default' => '',
			'options' => array(
				'button_text' => esc_html__( 'Unggah Buku Rekening', 'jnews-pay-writer' ),
				'library'     => 'image,application/pdf',
			),
		);

		$options['paypal_account'] = array(
			'segment' => 'jnews-paypal-credential',
			'title'   => esc_html__( 'Akun Paypal', 'jnews-pay-writer' ),
			'desc'    => wp_kses( __( 'Silakan masukkan ID akun Paypal atau email Paypal yang valid', 'jnews-pay-writer' ), wp_kses_allowed_html() ),
			'type'    => 'text',
			'default' => '',
		);

		return $options;
	}
}
